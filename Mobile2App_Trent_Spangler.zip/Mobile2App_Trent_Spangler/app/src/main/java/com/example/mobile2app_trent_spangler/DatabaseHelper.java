package com.example.mobile2app_trent_spangler;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String databaseName = "mobile2app_trent_spangler.db";
    private static final int databaseVersion = 1;

    public static final String tableUsers = "users";
    public static final String userID = "id";
    public static final String Username = "username";
    public static final String Password = "password";

    public static final String tableInventory = "inventory";
    public static final String itemID = "id";
    public static final String itemName = "name";
    public static final String itemQuantity = "quantity";

    public DatabaseHelper (Context context) {
        super (context, databaseName, null, databaseVersion);
    }

    @Override
    public void onCreate (SQLiteDatabase database) {
        String createUsersTable = "Create Table " + tableUsers + " ("
                + userID + " Integer Primary Key Autoincrement, "
                + Username + " Text Unique, " + Password + " Text)";
        database.execSQL(createUsersTable);

        String createInventoryTable = "Create Table " + tableInventory + " ("
                + itemID + " Integer Primary Key Autoincrement, "
                + itemName + " Text, " + itemQuantity + "Integer)";
        database.execSQL(createInventoryTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        database.execSQL("Drop Table if Exists " + tableUsers);
        database.execSQL("Drop Table if Exists " + tableInventory);
        onCreate(database);
    }

    public boolean userAuthenticateOrRegister (String username, String password) {
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.query(tableUsers, null, Username + "= ?", new String[]{username}, null, null, null);

        if (cursor.moveToFirst()) {
            int passIndex = cursor.getColumnIndex(Password);
            String savedPassword = cursor.getString(passIndex);
            cursor.close();
            return savedPassword.equals(password);
        }
        else {
            ContentValues values = new ContentValues();
            values.put(Username, username);
            values.put(Password, password);
            long result = database.insert(tableUsers, null, values);
            return result != -1;
        }
    }

    public boolean createItem (String name, int quantity) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(itemName, name);
        values.put(itemQuantity, quantity);
        return database.insert(tableInventory, null, values) != -1;
    }

    public Cursor readAllItems() {
        SQLiteDatabase database = this.getReadableDatabase();
        return database.rawQuery("Select * From " + tableInventory, null);
    }

    public boolean updateItem(int id, String name, int quantity) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(itemName, name);
        values.put(itemQuantity, quantity);
        return database.update(tableInventory, values, itemID + "= ?", new String[]{String.valueOf(id)}) > 0;
    }

    public boolean deleteItem(int id) {
        SQLiteDatabase database = this.getWritableDatabase();
        return database.delete(tableInventory, itemID + "= ?", new String []{String.valueOf(id)}) > 0;
    }
}
