package com.example.mobile2app_trent_spangler;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class MainActivity  extends AppCompatActivity {
    private static final int SMSPermissionCode = 101;
    private DatabaseHelper dbHelper;
    private GridView dataGrid;
    private EditText ItemName, ItemQuantity, ItemId;
    private Button buttonAdd, buttonUpdate, buttonDelete;
    private ArrayList<String> gridList;
    private ArrayAdapter<String> gridAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        dataGrid = findViewById(findViewById(R.id.dataGrid).getId());
        ItemName = findViewById(R.id.etItemName);
        ItemQuantity = findViewById(R.id.etItemQuantity);
        ItemId = findViewById(R.id.etItemId);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonUpdate = findViewById(R.id.buttonUpdate);
        buttonDelete = findViewById(R.id.buttonDelete);

        gridList = new ArrayList<>();
        gridAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, gridList);
        dataGrid.setAdapter(gridAdapter);

        checkSMSPermission();
        refreshGridData();

        buttonAdd.setOnClickListener(v -> {
            String name = ItemName.getText().toString().trim();
            String quantity = ItemQuantity.getText().toString().trim();

            if (!name.isEmpty() && !quantity.isEmpty()) {
                int qty = Integer.parseInt(quantity);
                dbHelper.createItem(name, qty);
                verifyAndTriggerAlert(name, qty);
                refreshGridData();
            }
        });

        buttonUpdate.setOnClickListener(v -> {
            String itemId = ItemId.getText().toString().trim();
            String name = ItemName.getText().toString().trim();
            String quantity = ItemQuantity.getText().toString().trim();

            if (!itemId.isEmpty() && !name.isEmpty() && !quantity.isEmpty()) {
                int id = Integer.parseInt(itemId);
                int qty = Integer.parseInt(quantity);
                dbHelper.updateItem(id, name, qty);
                verifyAndTriggerAlert(name, qty);
                refreshGridData();
            }
        });

        buttonDelete.setOnClickListener(v -> {
            String itemId = ItemId.getText().toString().trim();

            if (!itemId.isEmpty()) {
                dbHelper.deleteItem(Integer.parseInt(itemId));
                refreshGridData();
            }
        });
    }

    private void refreshGridData() {
        gridList.clear();
        Cursor cursor = dbHelper.readAllItems();

        if (cursor != null) {
            gridList.add("ID"); gridList.add("Item Name"); gridList.add("Quantity");

            while (cursor.moveToNext()) {
                gridList.add(String.valueOf(cursor.getInt(0)));
                gridList.add(cursor.getString(1));
                gridList.add(String.valueOf(cursor.getInt(2)));
            }
            cursor.close();
        }
        gridAdapter.notifyDataSetChanged();
    }

    private void checkSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMSPermissionCode);
        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String [] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMSPermissionCode) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Alerts Enabled", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "SMS Alerts Disabled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void verifyAndTriggerAlert (String itemName, int quantity) {
        if (quantity < 5) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                try {
                    SmsManager smsManager = this.getSystemService(SmsManager.class);
                    smsManager.sendTextMessage("5554", null, "Alert: Low inventory for " + itemName + " (" + quantity + ")", null, null);
                    Toast.makeText(this, "Low Stock text alert pushed", Toast.LENGTH_SHORT).show();
                }
                catch (Exception e) {
                    Toast.makeText(this, "SMS delivery failed", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}
